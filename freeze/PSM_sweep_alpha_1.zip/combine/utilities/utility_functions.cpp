//
//  utility_functions.cpp
//  tau+
//
//  Created by Matthew Fonken on 10/6/17.
//  Copyright © 2017 Marbl. All rights reserved.
//

#include "utility_functions.hpp"

cv::Vec3b preset(BRIGHTNESS,BRIGHTNESS,BRIGHTNESS);

