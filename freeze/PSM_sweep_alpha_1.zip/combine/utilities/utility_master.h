//
//  utility_master.h
//  combine_core
//
//  Created by Matthew Fonken on 1/21/18.
//  Copyright © 2018 Marbl. All rights reserved.
//

#ifndef utility_master_h
#define utility_master_h

#define UTILITY_VERBOSE

#include "environment_master.h"
#include "image_utility.hpp"

#endif /* utility_master_h */
