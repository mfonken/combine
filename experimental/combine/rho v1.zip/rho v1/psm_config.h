//
//  psm_config.h
//  ots-proto
//
//  Created by Matthew Fonken on 7/14/22.
//

#ifndef psm_config_h
#define psm_config_h

#define MAX_OBSERVATIONS        (1 << 4)

#endif /* psm_config_h */
