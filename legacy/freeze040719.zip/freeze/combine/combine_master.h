//
//  combine_master.h
//  combine_core
//
//  Created by Matthew Fonken on 1/21/18.
//  Copyright © 2018 Marbl. All rights reserved.
//

#ifndef combine_master_h
#define combine_master_h

#include "combine.hpp"

#endif /* combine_master_h */
