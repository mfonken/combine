//
//  tau_master.h
//  tau+
//
//  Created by Matthew Fonken on 2/8/18.
//  Copyright © 2018 Marbl. All rights reserved.
//

#ifndef tau_master_h
#define tau_master_h

#include <stdio.h>
#include <stdint.h>

#include "tau_drawer.hpp"

#endif /* tau_master_h */
